<?php

/*

 Saves the file tree view on the onSite user interface.

 Written by Richard McMullen <mcmullen@florin.com>
 Released under the GNU General Public License version 3
 http://www.opensource.org/licenses/gpl-3.0.html

 Project Home Page: http://www.florin.com/onsite/index.html

*/
    session_start();
    
    $action = $_REQUEST['action'];
 
    switch($action) {

        case "start":
        
            $siteconfig = $_REQUEST["siteconfig"];   
            
            require_once "config-read.php";
            
            $directory_base = $varray["directory_base"];
            $directory_onsite = $directory_base . "/" . $varray["directory_onsite"]; 
            $directory_data = $directory_onsite . "/" . $varray["directory_data"];
             
            $_SESSION['xfe'] = $directory_data . "/" . $varray["filelist_excluded"]; 

            $_SESSION['xdr'] = $varray["directory_root"];
                  
            $xfe = fopen($_SESSION['xfe'], "w");
           
            fclose($xfe); 

            break;
            
            
       case "end":
                   
            session_destroy();

            break;
            
            
        default :            
 
            $xfe = fopen($_SESSION['xfe'], "a");    
  
            $lfc = $_REQUEST['lfc']; 
 
            $exclist = $_SESSION['xdr'] . $lfc;
            
            if(is_file($exclist)) fwrite($xfe, $exclist . "\n"); 

            fclose($xfe); 

            break;
            
    } 
		
?>