<?php

/*

 Saves the sitemap.xml from the onSite user interface.

 Written by Richard McMullen <mcmullen@florin.com>
 Released under the GNU General Public License version 3
 http://www.opensource.org/licenses/gpl-3.0.html

 Project Home Page: http://www.florin.com/onsite/index.html

*/
    session_start();
    
    $action = $_REQUEST['action'];
 
    switch($action) {

        case "start":
        
            $siteconfig = $_REQUEST["siteconfig"];   
            
            require_once "config-read.php";
            
            $directory_base = $varray["directory_base"];
            $directory_onsite = $directory_base . "/" . $varray["directory_onsite"]; 
            $directory_data = $directory_onsite . "/" . $varray["directory_data"];
            $directory_sitemap = $directory_onsite . "/" . $varray["directory_sitemap"];
            
            $_SESSION['xfs'] = $directory_sitemap . "/" . $varray["filename_sitemap"];
            $_SESSION['xfu'] = $directory_sitemap . "/" . $varray["urllist_sitemap"];
            $_SESSION['xfl'] = $directory_data . "/" . $varray["filelist_included"]; 

            $_SESSION['xdn'] = $varray["domain_url"];
            $_SESSION['xdr'] = $varray["directory_root"];
              
            $xmlhead = '<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">';

            $xfs = fopen($_SESSION['xfs'], "w");
            $xfu = fopen($_SESSION['xfu'], "w");    
            $xfl = fopen($_SESSION['xfl'], "w");    

            fwrite($xfs, $xmlhead . "\n");
            
            fclose($xfs);
            fclose($xfu);
            fclose($xfl); 

            break;
            
            
       case "end":
        
            $xmlfoot = '</urlset>';
            
            $xfs = fopen($_SESSION['xfs'], "a");
            
            fwrite($xfs, $xmlfoot);
            
            fclose($xfs);
            
            session_destroy();
  
            break;
            
            
        default :            
                
            $xfs = fopen($_SESSION['xfs'], "a");
            $xfu = fopen($_SESSION['xfu'], "a");    
            $xfl = fopen($_SESSION['xfl'], "a");    
  
            $smu = $_REQUEST['smu']; 
            $sml = $_REQUEST['sml'];  
            $ssf = $_REQUEST['ssf']; 
            $ssp = $_REQUEST['ssp']; 
 
            $inclist = $_SESSION['xdr'] . $smu;
            
            if(is_file($inclist)){ 
 
                $ftime = filemtime($inclist);
                $sml = date("Y-m-d", $ftime) . "T" . date("H:i:s", $ftime) . "Z";
                
                $urllistall = $_SESSION['xdn'] . $smu . 
                ' priority=' . $ssp  . 
                ' changefreq=' . $ssf . 
                ' lastmod=' . $sml;
                
                $sitemap = " <url>\n  <loc>" . $_SESSION['xdn'] . $smu . 
                "</loc>\n  <priority>" . $ssp  . 
                "</priority>\n  <changefreq>" . $ssf . 
                "</changefreq>\n  <lastmod>" . $sml . 
                "</lastmod>\n </url>";
                
 
                fwrite($xfs, $sitemap . "\n");
                fwrite($xfu, $urllistall . "\n");    
                fwrite($xfl, $inclist . "\n");
                
            }

            fclose($xfs);
            fclose($xfu);
            fclose($xfl); 

            break;
            
    } 
 
?>